public class GameState {
    private static GameState instance;
    public int level;
    public int score;

    private GameState() {
        // Initialize the game state
        level = 1;
        score = 0;
    }

    public static GameState getInstance() {
        if (instance == null) {
            instance = new GameState();
        }
        return instance;
    }
}

// Usage
GameState gameState = GameState.getInstance();
abstract class Enemy {
    public abstract void attack();
}

class Goblin extends Enemy {
    @Override
    public void attack() {
        System.out.println("Goblin attacks!");
    }
}

class Troll extends Enemy {
    @Override
    public void attack() {
        System.out.println("Troll attacks!");
    }
}

class EnemyFactory {
    public static Enemy createEnemy(String enemyType) {
        switch (enemyType) {
            case "goblin":
                return new Goblin();
            case "troll":
                return new Troll();
            default:
                throw new IllegalArgumentException("Unknown enemy type");
        }
    }
}

// Usage
Enemy enemy = EnemyFactory.createEnemy("goblin");
enemy.attack();
abstract class Weapon {
    public abstract void use();
}

class Sword extends Weapon {
    @Override
    public void use() {
        System.out.println("Swinging sword!");
    }
}

class Bow extends Weapon {
    @Override
    public void use() {
        System.out.println("Shooting arrow!");
    }
}

abstract class PowerUp {
    public abstract void apply();
}

class HealthPotion extends PowerUp {
    @Override
    public void apply() {
        System.out.println("Restoring health!");
    }
}

class Shield extends PowerUp {
    @Override
    public void apply() {
        System.out.println("Activating shield!");
    }
}

abstract class AbstractFactory {
    public abstract Weapon createWeapon();
    public abstract PowerUp createPowerUp();
}

class EasyLevelFactory extends AbstractFactory {
    @Override
    public Weapon createWeapon() {
        return new Sword();
    }

    @Override
    public PowerUp createPowerUp() {
        return new HealthPotion();
    }
}

class HardLevelFactory extends AbstractFactory {
    @Override
    public Weapon createWeapon() {
        return new Bow();
    }

    @Override
    public PowerUp createPowerUp() {
        return new Shield();
    }
}

// Usage
AbstractFactory factory = new EasyLevelFactory();
Weapon weapon = factory.createWeapon();
PowerUp powerUp = factory.createPowerUp();
weapon.use();
powerUp.apply();
